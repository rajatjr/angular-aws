const mongoose = require('mongoose');

const planSchema = new mongoose.Schema({
  stripePlanId: {
    type: String,
    required: true,
  },
  stripePriceId: {
    type: String,
    required: true,
  },
  productId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Product',
    required: true,
  },
  amount: {
    type: Number,
    required: true,
  },
  currency: {
    type: String,
    required: true,
  },
  interval: {
    type: String,
    required: true,
  },
}, { timestamps: true });

module.exports = mongoose.model('Plan', planSchema);
