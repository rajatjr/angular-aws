const stripe = require('stripe')('sk_test_51PlpFzBzQN0nt5X1PCA0rcobm1nlHx9C31ekDku9BsdVFjPMhwwcvN1abJC8RQfmIlXiyPuIDDzG2yOlht7Sh7BA00gbAvDlET');
// const Product = require('../models/Product');
// const Plan = require('../models/Plan');
const PaymentIntent = require('../models/paymentIntent');

exports.createProduct = async (name, description) => {
  try {
    const product = await stripe.products.create({
      name,
      description,
    });
    return product;
  } catch (error) {
    console.error('Error creating Stripe product:', error);
    throw error;
  }
};

exports.createStripePlan = async (productId, amount, currency, interval) => {
  try {
    const plan = await stripe.prices.create({
      unit_amount: amount,
      currency: currency,
      recurring: { interval: interval },
      product: productId,
    });
    return plan;
  } catch (error) {
    console.error('Error creating Stripe plan:', error);
    throw error;
  }
};



exports.createPrice = async (productId, amount, currency, interval) => {
  try {
    const price = await stripe.prices.create({
      unit_amount: amount,
      currency: currency,
      recurring: { interval: interval },
      product: productId,
    });
    return price;
  } catch (error) {
    console.error('Error creating Stripe price:', error);
    throw error;
  }
};


exports.createPaymentIntent = async (amount) => {
  const paymentIntent = await stripe.paymentIntents.create({
    amount,
    currency: 'usd',
  });

  const newPaymentIntent = new PaymentIntent({
    stripePaymentIntentId: paymentIntent.id,
    amount: paymentIntent.amount,
    currency: paymentIntent.currency,
    status: paymentIntent.status,
  });

  await newPaymentIntent.save();
  return paymentIntent;
};
