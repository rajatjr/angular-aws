const bcrypt = require("bcryptjs");
const Admin = require("../models/adminmodel");
const jwt = require("jsonwebtoken");

exports.AdminLogin = async (req, res) => {
  const { email, password } = req.body;

  try {
    const admin = await Admin.findOne({ email });
    if (!admin) {
      return res
        .status(400)
        .json({ success: false, msg: "Invalid Credentials" });
    }

    const isMatch = await bcrypt.compare(password, admin.password);
    if (!isMatch) {
      return res
        .status(400)
        .json({ success: false, msg: "Invalid Credentials" });
    }

    const payload = { admin: { id: admin.id, role: "admin" } };
    jwt.sign(
      payload,
      process.env.JWT_SECRET,
      { expiresIn: "1hr" },
      async (err, token) => {
        if (err) throw err;

        admin.lastLogin = new Date();
        await admin.save();

        res.json({
          success: true,
          msg: "Admin logged in",
          token,
          name: admin.name,
          lastLogin: admin.lastLogin,
        });
      }
    );
  } catch (error) {
    console.error(error);
    return res
      .status(500)
      .json({ success: false, error: "Internal server error" });
  }
};

exports.AdminSignUp = async (req, res) => {
  try {
    const { email, password } = req.body;

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const createAdmin = new Admin({
      email,
      password: hashedPassword,
    });

    await createAdmin.save();
    return res.status(200).json({ success: true, msg: "Admin has registered" });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ success: false, error });
  }
};
