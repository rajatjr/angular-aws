const stripe = require('stripe')('sk_test_51PlpFzBzQN0nt5X1PCA0rcobm1nlHx9C31ekDku9BsdVFjPMhwwcvN1abJC8RQfmIlXiyPuIDDzG2yOlht7Sh7BA00gbAvDlET');
const { createPaymentIntent, createProduct, createStripePlan, createPrice } = require('../services/stripeService');
const Product = require('../models/Product');
const Plan = require('../models/Plan');
const PaymentIntent = require('../models/paymentIntent');

exports.createPlan = async (req, res) => {
  const { name, description, amount, currency, interval } = req.body;

  try {
    // Step 1: Create the Product on Stripe
    const stripeProduct = await createProduct(name, description);
    if (!stripeProduct) {
      return res.status(400).json({ error: 'Failed to create product on Stripe' });
    }

    // Step 2: Save the Product to MongoDB
    const newProduct = new Product({
      stripeProductId: stripeProduct.id,
      name,
      description,
    });
    await newProduct.save();

    // Step 3: Create the Plan (Price) on Stripe
    const plan = await createStripePlan(stripeProduct.id, amount, currency, interval);
    if (!plan) {
      return res.status(400).json({ error: 'Failed to create plan on Stripe' });
    }

    // Step 4: Create the Price on Stripe
    const price = await createPrice(stripeProduct.id, amount, currency, interval);
    if (!price) {
      return res.status(400).json({ error: 'Failed to create price on Stripe' });
    }

    // Step 5: Save the Plan and Price to MongoDB
    const newPlan = new Plan({
      stripePlanId: plan.id,
      stripePriceId: price.id,
      productId: newProduct._id,
      amount,
      currency,
      interval,
    });
    await newPlan.save();

    // Step 6: Respond with the created product and plan details
    res.status(200).json({
      message: 'Product, Plan, and Price created successfully',
      product: newProduct,
      plan: newPlan,
    });
  } catch (error) {
    console.error('Error creating plan:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};

exports.createPaymentIntent = async (req, res) => {
  const { amount } = req.body;

  try {
    const paymentIntent = await createPaymentIntent(amount);
    return res.status(200).json({
      success: true,
      clientSecret: paymentIntent.client_secret,
    });
  } catch (error) {
    console.error('Error creating payment intent:', error);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
};



exports.getAllProducts = async (req, res) => {
  try {
    const products = await Product.find();
    res.status(200).json({
      success: true,
      data: products
    });
  } catch (error) {
    console.error('Error fetching products:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};



exports.getProductById = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }
    res.status(200).json({
      success: true,
      data: product
    });
  } catch (error) {
    console.error('Error fetching product:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};



exports.getAllPlans = async (req, res) => {
  try {
    const plans = await Plan.find();
    res.status(200).json({
      success: true,
      data: plans
    });
  } catch (error) {
    console.error('Error fetching plans:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};




exports.getPlanById = async (req, res) => {
  try {
    const plan = await Plan.findById(req.params.id);
    if (!plan) {
      return res.status(404).json({ error: 'Plan not found' });
    }
    res.status(200).json({
      success: true,
      data: plan
    });
  } catch (error) {
    console.error('Error fetching plan:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};




exports.getAllPaymentIntents = async (req, res) => {
  try {
    const paymentIntents = await PaymentIntent.find();
    res.status(200).json({
      success: true,
      data: paymentIntents
    });
  } catch (error) {
    console.error('Error fetching payment intents:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};



exports.getPaymentIntentById = async (req, res) => {
  try {
    const paymentIntent = await PaymentIntent.findById(req.params.id);
    if (!paymentIntent) {
      return res.status(404).json({ error: 'Payment Intent not found' });
    }
    res.status(200).json({
      success: true,
      data: paymentIntent
    });
  } catch (error) {
    console.error('Error fetching payment intent:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};




exports.createCheckoutSession = async (req, res) => {
  const { planId } = req.body;

  try {
    // Retrieve the plan from your database using the planId
    const plan = await Plan.findById(planId);
    if (!plan) {
      return res.status(404).json({ error: 'Plan not found' });
    }

    // Create the Checkout Session
    const session = await stripe.checkout.sessions.create({
      payment_method_types: ['card'],
      line_items: [
        {
          price: plan.stripePriceId, // Stripe Price ID
          quantity: 1,
        },
      ],
      mode: 'subscription', // You can also use 'payment' for one-time payments
      success_url: `http://localhost:4200/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `http://localhost:4200//cancel`,
    });

    // Respond with the session ID
    res.status(200).json({ sessionId: session});
  } catch (error) {
    console.error('Error creating checkout session:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
};
