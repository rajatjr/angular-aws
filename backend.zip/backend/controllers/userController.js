const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { registerSchema, loginSchema, updateProfileSchema, toggleUserStatusSchema } = require('../validators/userValidator');
const upload = require('../middleware/multer'); 

// User Registration
const AWS = require('aws-sdk');
const fs = require('fs');
const path = require('path');

// Configure AWS SDK
const s3 = new AWS.S3({
  accessKeyId: "AKIAVHDFJ5RDQODZMDH4",
  secretAccessKey: "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",
  region: 'ap-south-1'
});



exports.register = async (req, res) => {
  const { name, email, password, address, phoneNumber } = req.body;

  try {
    // Check for existing user by email or phone number
    let user = await User.findOne({ $or: [{ email }, { phoneNumber }] });
    if (user) return res.status(400).json({ msg: 'User already exists' });

    // Helper function to upload files to S3 and return their URL
    const uploadFileToS3 = async (file) => {
      const params = {
        Bucket: 'admins3user',
        Key: `${Date.now()}_${file.originalname}`, // Unique file name
        Body: file.buffer,
        ContentType: file.mimetype,
      };
      const { Location } = await s3.upload(params).promise();
      return Location;
    };

    // Upload files (image, audio, video) if they exist and update the body
    const fileTypes = ['image', 'audio', 'video'];
    for (const type of fileTypes) {
      if (req.files[type]) {
        req.body[type] = await uploadFileToS3(req.files[type][0]);
      }
    }

    // Save user data and return token
    user = new User(req.body);
    await user.save();

    const payload = { user: { id: user.id } };
    jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1h' }, (err, token) => {
      if (err) throw err;
      res.json({
        msg: 'User created successfully',
        token,
        name: user.name,
        address: user.address,
        phoneNumber: user.phoneNumber,
        image: user.image,
        audio: user.audio,
        video: user.video,
      });
    });
  } catch (err) {
    console.error("Error: ", err.message);
    res.status(500).send('Server error');
  }
};


// User login
exports.login = async (req, res) => {
  const { error } = loginSchema.validate(req.body);
  if (error) {
    return res.status(400).json({ msg: error.details[0].message });
  }

  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ msg: 'Invalid Credentials' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ msg: 'Invalid Credentials' });
    }

    const payload = { user: { id: user.id } };
    jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1hr' }, (err, token) => {
      res.json({ 
        msg: 'Login successful', 
        token,
        name: user.name,
        lastLogin: user.lastLogin
      });
    });

    user.lastLogin = new Date(); // Update last login time
    await user.save();
  } catch (err) {
    res.status(500).send('Server error');
  }
};

// User profile update
exports.updateProfile = async (req, res) => {
  console.log("req.body: ", req.body)
  const { error } = updateProfileSchema.validate(req.body);
  if (error) {
    return res.status(400).json({ msg: error.details[0].message });
  }

  const { name, address, phoneNumber } = req.body;
  const { userId } = req.params; // get the user ID from the request parameters

  console.log("userId", userId);

  try {
    let user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ msg: 'User not found' });
    }

    // Check for duplicate phone number
    if (phoneNumber) {
      const duplicatePhone = await User.findOne({ phoneNumber });
      if (duplicatePhone && duplicatePhone.id !== user.id) {
        return res.status(400).json({ msg: 'Phone number already exists' });
      }
    }

    // Update user fields
    if (name) user.name = name;
    if (address) user.address = address;
    if (phoneNumber) user.phoneNumber = phoneNumber;

    await user.save();

    res.json({ msg: 'User profile updated successfully', user });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
};

// getUserById 
exports.getUserById = async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password'); // Exclude the password field
    if (!user) {
      return res.status(404).json({ msg: 'User not found' });
    }
    res.json(user);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

// getAllUsers
// exports.getAllUsers = async (req, res) => {

//   const page = parseInt(req.query.page) || 1; // Default to page 1
//   const limit = parseInt(req.query.limit) || 5; // Default to 5 users per page
//   const skip = (page - 1) * limit;
//   try {
//     const users = await User.find().select('-password').skip(skip).limit(limit); // Exclude the password field

//     const totalUsers = await User.countDocuments();
//     const totalPages = Math.ceil(totalUsers / limit);
//     res.json({
//       users,
//       totalPages,
//       currentPage: page,
//       totalUsers,
//     });

//   } catch (err) {
//     console.error(err.message);
//     res.status(500).send('Server error');
//   }
// };



exports.getAllUsers = async (req, res) => {
  const { page = 1, limit = 5, name, email } = req.query;
  const skip = (page - 1) * limit;
  const query = {};

  if (name) {
    query.name = { $regex: name, $options: 'i' }; // Case-insensitive search for name
  }
  if (email) {
    query.email = { $regex: email, $options: 'i' }; // Case-insensitive search for email
  }

  try {
    const users = await User.find(query).skip(skip).limit(parseInt(limit)).exec();
    const totalUsers = await User.countDocuments(query).exec(); // Get total count for pagination

    res.json({
      users,
      totalPages: Math.ceil(totalUsers / limit), // Calculate total pages
      currentPage: parseInt(page)
    });
  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({ error: 'Server error' });
  }
};



// deleteUser
exports.deleteUser = async (req, res) => {
  const { userId } = req.params;
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) {
      return res.status(404).json({ msg: 'User not found' });
    }

    res.json({ msg: 'User deleted successfully' });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};

// active / inactive user
exports.toggleUserStatus = async (req, res) => {
  const { error } = toggleUserStatusSchema.validate(req.body);
  if (error) {
    return res.status(400).json({ msg: error.details[0].message });
  }

  const { action } = req.body; // Expecting 'activate' or 'deactivate'
  const userId = req.params.id;

  try {
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ msg: 'User not found' });
    }

    user.isActive = action === 'activate'; // Set isActive based on action
    await user.save();

    res.json({ 
      msg: `User ${action}d successfully`, 
      user 
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};


// searchUsers
exports.searchUsers = async (req, res) => {
  const { name, email } = req.query;
  const searchQuery = {};

  // Build the search query based on the parameters provided
  if (name) {
    searchQuery.name = { $regex: name, $options: 'i' }; // Case-insensitive search by name
  }

  if (email) {
    searchQuery.email = { $regex: email, $options: 'i' }; // Case-insensitive search by email
  }

  try {
    const users = await User.find(searchQuery).select('-password'); // Exclude the password field

    if (users.length === 0) {
      return res.status(404).json({ msg: 'No users found' });
    }

    res.json(users);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server error');
  }
};
