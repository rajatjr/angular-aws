const Joi = require('joi');

const registerSchema = Joi.object({
  name: Joi.string().required(),
  email: Joi.string().email().required(),
  password: Joi.string().min(5).required(),
  address: Joi.string().required(),
  phoneNumber: Joi.string().length(10).pattern(/^\d+$/).required(),
  //image: Joi.string().required(),
});

const loginSchema = Joi.object({
  email: Joi.string().email().required(),
  password: Joi.string().required(),
});

const updateProfileSchema = Joi.object({
  name: Joi.string().optional(),
  address: Joi.string().optional(),
  phoneNumber: Joi.string().length(10).pattern(/^\d+$/).optional(),
});

const toggleUserStatusSchema = Joi.object({
  action: Joi.string().valid('activate', 'deactivate').required(),
});

module.exports = {
  registerSchema,
  loginSchema,
  updateProfileSchema,
  toggleUserStatusSchema,
};
