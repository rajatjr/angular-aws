const expressBasicAuth = require('express-basic-auth');
const swaggerUi = require('swagger-ui-express');
const {
    register,
    login,
    updateProfile,
    getUserById,
    getAllUsers,
    deleteUser,
    toggleUserStatus,
    searchUsers,
    createPlan,
    createPaymentIntent,
    getAllProducts,
    getProductById,
    getAllPlans,
    getPlanById,
    getAllPaymentIntents,
    getPaymentIntentById,
    createCheckoutSession
} = require('./api-docs/user');

const swaggerDocs = {
    "swagger": "2.0",
    "info": {
        "description": "Job Portal application API documentation",
        "version": "1.0.0",
        "title": "Swagger Angular Project"
    },
    "host": "localhost:5000",
    "schemes": [
        "http",
        "https"
    ],
    "tags": [
        {
            "name": "User Auth API",
            "description": "User authentication API endpoints"
        }
        // Add other tags as needed
    ],
    "paths": {
        "/api/auth/register": register,
        "/api/auth/login": login,
        "/api/auth/updateProfile": updateProfile,
        "/api/auth/getUserById/{id}": getUserById,
        "/api/auth/getAllUsers": getAllUsers,
        "/api/auth/deleteUser/{id}": deleteUser,
        "/api/auth/users/status/{id}": toggleUserStatus,
        "/api/auth/searchUsers": searchUsers,
        "/api/auth/create-plan": createPlan,
        "/api/auth/create-payment-intent": createPaymentIntent,
        "/api/auth/getAllproducts": getAllProducts,
        "/api/auth/products/{id}": getProductById,
        "/api/auth/getAllplans": getAllPlans,
        "/api/auth/plans/{id}": getPlanById,
        "/api/auth/getAllpayment-intents": getAllPaymentIntents,
        "/api/auth/payment-intents/{id}": getPaymentIntentById,
        "/api/auth/create-checkout-session": createCheckoutSession

        // Add other paths as needed
    },
    "securityDefinitions": {
        "Bearer": {
            "type": "apiKey",
            "name": "Authorization",
            "in": "header"
        }
    }
};

const swaggerRoute = (app) => {
    app.use("/api-docs", expressBasicAuth({
        users: { 'swagger': 'beu4gebf9' },
        unauthorizedResponse: (req) => {
            return req.auth ? 'Invalid credentials' : 'No credentials provided';
        },
        challenge: true,
        realm: 'Swagger Realm'
    }), swaggerUi.serve, swaggerUi.setup(swaggerDocs));
};

module.exports = { swaggerRoute };
