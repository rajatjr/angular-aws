const multer = require("multer");
const path = require("path");

const storage = multer.memoryStorage(); // Using memory storage for S3 uploads

const upload = multer({
  storage: storage,
  fileFilter: (req, file, cb) => {
    if (
      file.mimetype.startsWith("image/") ||
      file.mimetype.startsWith("audio/") ||
      file.mimetype.startsWith("video/")) {
      cb(null, true);
    } else {
      cb(
        new Error(
          "Invalid file type. Only images and audio,and video files are allowed."
        ),
        false
      );
    }
  },
});

module.exports = upload;
