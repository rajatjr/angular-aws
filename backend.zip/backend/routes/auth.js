const express = require('express');
const { AdminLogin, AdminSignUp } = require('../controllers/adminController');
const router = express.Router();
const userController = require('../controllers/userController');
const authMiddleware = require('../middleware/authMiddleware');
const adminAuthMiddleware = require('../middleware/adminAuthMiddleware'); 
const upload = require("../middleware/multer")
const paymentController = require('../controllers/paymentController');

router.post('/adminlogin', AdminLogin);
router.post('/AdminSignUp', AdminSignUp);

// User registration and login routes
router.post('/register', upload.fields([{ name: 'image' }, { name: 'audio' }, { name: 'video'}]),userController.register);
router.post('/login', userController.login);

// Profile management routes
router.patch('/updateProfile/:userId', authMiddleware, adminAuthMiddleware, userController.updateProfile); // Update user profile
router.get('/user/:id', authMiddleware, userController.getUserById); // Get user by ID
router.get('/getAllUsers', authMiddleware, userController.getAllUsers); // Get all users
router.delete('/deleteUser/:id', authMiddleware, adminAuthMiddleware, userController.deleteUser); // Delete user
router.put('/users/status/:id', authMiddleware, adminAuthMiddleware, userController.toggleUserStatus); // Toggle user status

// Search users by name and/or email
router.get('/searchUsers', authMiddleware, userController.searchUsers); // Search users

/** 
 *apis for stripe implementation 
 */

 // No Token APIS

 router.post('/create-plan', paymentController.createPlan);
 router.post('/create-payment-intent', paymentController.createPaymentIntent);

// GET APIs
router.get('/getAllproducts', paymentController.getAllProducts);
router.get('/products/:id', paymentController.getProductById);
router.get('/getAllplans', paymentController.getAllPlans);
router.get('/plans/:id', paymentController.getPlanById);
router.get('/getAllpayment-intents', paymentController.getAllPaymentIntents);
router.get('/payment-intents/:id', paymentController.getPaymentIntentById);


router.post('/create-checkout-session', paymentController.createCheckoutSession);


module.exports = router;