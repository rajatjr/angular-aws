import { Injectable } from '@angular/core';
import { AuthServicesService } from './auth-services.service';
import { CanActivate, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService implements CanActivate {

  constructor(
    private loginService: AuthServicesService,
    private router: Router
  ) { }

  canActivate(): Observable<boolean> {

    return this.loginService.isLoggedIn().pipe(
      map(loggedIn => {

        if (loggedIn) {

          return true;
        } else {
          this.router.navigate(['/adminlogin']);
          return false;
        }
      })
    );
  }
}
