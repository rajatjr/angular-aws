// src/app/service/auth-services.service.ts
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthServicesService {

  private loggedIn = new BehaviorSubject<boolean>(false)

  isLoggedIn(){
    return this .loggedIn.asObservable()
  }

  logIn(){
    const token = localStorage.getItem('token')
    if(token) return this.loggedIn.next(true)
    return this.loggedIn.next(false)
  }

  logOut(){
    return this.loggedIn.next(false)
  }



  baseUrl: any = 'http://localhost:5000/api';

  constructor(private http: HttpClient) { }

  private createUrl(endpoint: string): string {
    return `${this.baseUrl}/${endpoint}`;
  }

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('token'); // Replace with actual token retrieval logic
    return new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
  }

  // GET request
  get(endpoint: string, options?: any): Observable<any> {
    const url = this.createUrl(endpoint);
    const headers = this.getAuthHeaders();
    return this.http.get(url, { headers, ...options });
  }

  // POST request
  post(endpoint: string, data: any, options?: any): Observable<any> {
    const url = this.createUrl(endpoint);
    const headers = this.getAuthHeaders();
    return this.http.post(url, data, { headers, ...options });
  }

  // PUT request
  put(endpoint: string, data: any, options?: any): Observable<any> {
    const url = this.createUrl(endpoint);
    const headers = this.getAuthHeaders();
    return this.http.put(url, data, { headers, ...options });
  }

  // PATCH request
  patch(endpoint: string, data: any, options?: any): Observable<any> {
    const url = this.createUrl(endpoint);
    const headers = this.getAuthHeaders();
    return this.http.patch(url, data, { headers, ...options });
  }

  // DELETE request
  delete(endpoint: string, options?: any): Observable<any> {
    const url = this.createUrl(endpoint);
    const headers = this.getAuthHeaders();
    return this.http.delete(url, { headers, ...options });
  }

  // Fetch all plans
  getPlans(): Observable<any> {
    return this.get('auth/getAllplans');
  }

   // Checkout and make payment
   createCheckoutSession(planId: string): Observable<any> {
    const url = this.createUrl('auth/create-checkout-session');
    const headers = this.getAuthHeaders();
    return this.http.post(url, { planId }, { headers });
  }
}

