// src/app/login/login.component.ts
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { AuthServicesService } from '../../services/auth-services.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminLoginComponent implements OnInit {
  loginForm!: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private http: HttpClient,
    private router: Router,
    private toastr: ToastrService,
    private authservice:AuthServicesService
  ) {}

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(4)]]
    });
  }
  onSubmit(): void {
    if (this.loginForm.valid) {
      this.authservice.post('auth/adminlogin', this.loginForm.value)
        .subscribe(
          (response: any) => {
            console.log('Login successful', response);
            this.toastr.success('Login successful');
            // Save the token to local storage
            localStorage.setItem('token', response.token);
            // Navigate to dashboard or any other desired page
            this.router.navigate(['/dashboard']);
            this.authservice.logIn();
          },
          (error) => {
            console.error('Login failed', error);
            this.toastr.error('Login failed. Please check your credentials.');
            // Handle login error, e.g., display error message
          }
        );
    }
  }

}
