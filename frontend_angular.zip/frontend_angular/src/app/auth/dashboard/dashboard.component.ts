// src/app/dashboard/dashboard.component.ts

import { Component, OnInit, TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { AuthServicesService } from '../../services/auth-services.service';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
subscribe(arg0: any) {
throw new Error('Method not implemented.');
}
  users: any[] = [];
  selectedUser: any = null; // Set initial state to null
  private modalRef: NgbModalRef | undefined;
  sortColumn: string = '';
  sortDirection: string = 'asc';
  currentPage: number = 1;
  totalPages: number = 1;
  searchQuery: string = '';
  plans: any[] = [];

  constructor(
    public authservice: AuthServicesService,
    private router: Router,
    private modalService: NgbModal,
    private toastr: ToastrService // Inject ToastrService
  ) { }

  ngOnInit(): void {
    this.getAllUser();
    this.fetchPlans();
  }

  // getAllUser(page: number = 1, limit: number = 5) {
  //   this.authservice.get(`auth/getAllUsers?page=${page}&limit=${limit}`).subscribe(
  //     data => {
  //       this.users = data.users; // Assuming the response is paginated with a 'users' field
  //     this.totalPages = data.totalPages; // Store the total number of pages
  //     this.currentPage = data.currentPage; // Store the current page
  //     console.log('Userdata:', this.users);
  //     },
  //     error => {
  //       console.error('Error fetching users:', error);
  //     }
  //   );
  // }

  fetchPlans() {
    this.authservice.getPlans().subscribe(
      data => {
        this.plans = data.data;
      },
      error => {
        console.error('Error fetching plans:', error);
      }
    );
  }


  buyPlan(planId: string) {
    this.authservice.createCheckoutSession(planId).subscribe(
      response => {
        console.log("response >>",response)
        // Redirect to Stripe checkout
       window.location.href = response.sessionId.url;
      },
      error => {
        console.error('Error creating checkout session:', error);
      }
    );
  }

  getAllUser(page: number = 1, limit: number = 5) {
    let url = `auth/getAllUsers?page=${page}&limit=${limit}`;

    // Add search parameters if present
    if (this.searchQuery) {
      url += `&name=${this.searchQuery}&email=${this.searchQuery}`;
    }

    this.authservice.get(url).subscribe(
      data => {
        this.users = data.users;
        this.totalPages = data.totalPages;
        this.currentPage = data.currentPage;
        console.log('Userdata:', this.users);
      },
      error => {
        console.error('Error fetching users:', error);
      }
    );
  }

  searchUsers() {
    this.getAllUser(1); // Reset to first page on search
  }

  toggleUserStatus(user: any) {
    const action = user.isActive ? 'deactivate' : 'activate';
    this.authservice.put(`auth/users/status/${user._id}`, { action }).subscribe(
      response => {
        user.isActive = !user.isActive; // Update user status in UI
        this.toastr.success(`User ${action}d successfully`);
      },
      error => {
        console.error(`Error ${action}ing user:`, error);
        this.toastr.error(`Error ${action}ing user`);
      }
    );
  }

  openUpdateModal(content: TemplateRef<any>, user: any) {
    this.selectedUser = { ...user }; // Copy user data to selectedUser
    this.modalRef = this.modalService.open(content); // Open modal with the provided template reference
  }

  updateUser(modal: NgbModalRef) {
    if (this.selectedUser) {
      console.log("this.sele: ", this.selectedUser);
      let user = {
        name: this.selectedUser.name,
        address: this.selectedUser.address,
        phoneNumber: this.selectedUser.phoneNumber
      };
      this.authservice.patch(`auth/updateProfile/${this.selectedUser._id}`, user).subscribe(
        response => {
          console.log('User updated successfully:', response);
          this.toastr.success('User updated successfully');
          this.getAllUser(); // Refresh user list
          modal.close(); // Close modal
        },
        error => {
          console.error('Error updating user:', error);
          this.toastr.error('Error updating user');
        }
      );
    }
  }

  deleteUser(userId: string) {
    if (confirm('Are you sure you want to delete this user?')) {
      this.authservice.delete(`auth/deleteUser/${userId}`).subscribe(
        response => {
          console.log('User deleted successfully:', response);
          this.toastr.success('User deleted successfully');
          this.getAllUser(); // Refresh user list
        },
        error => {
          console.error('Error deleting user:', error);
          this.toastr.error('Error deleting user');
        }
      );
    }
  }

  logout() {
    localStorage.removeItem('token');
    this.toastr.success('Logged out successfully');
    this.router.navigate(['/adminlogin']);
  }

  getImageUrl(imagePath: string): string {
    return `http://localhost:5000/${imagePath}`; // Adjust this based on your backend setup
  }

  downloadCSV() {
    const csvData = this.convertToCSV(this.users);
    const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'users.csv';
    a.click();
    URL.revokeObjectURL(url);
  }
  private convertToCSV(users: any[]): string {
    const header = 'Name,Email,Address,Phone Number,Last Login,Status\n';
    const rows = users.map(user => {
      const lastLogin = new Date(user.lastLogin).toLocaleString();
      const status = user.isActive ? 'Active' : 'Inactive';
      return `${user.name},${user.email},${user.address},${user.phoneNumber},"${lastLogin}",${status}`;
    }).join('\n');
    return header + rows;
  }
  sortData(column: string) {
    if (this.sortColumn === column) {
      this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
    } else {
      this.sortColumn = column;
      this.sortDirection = 'asc';
    }

    this.users.sort((a, b) => {
      const valueA = a[column];
      const valueB = b[column];

      let comparison = 0;

      if (valueA > valueB) {
        comparison = 1;
      } else if (valueA < valueB) {
        comparison = -1;
      }

      return this.sortDirection === 'asc' ? comparison : -comparison;
    });
  }

}
